$(document).ready(function () {
    $('#modalbutton').click(function () {
       $('#terms').modal(); 
    });
});